package com.example.wagba;

import android.app.Application;
import android.os.AsyncTask;

import java.util.List;

public class ProfileRepository {
    private final ProfileDataDao mProfileDao;
    private final List<ProfileData> getAllData;
    public ProfileRepository(Application app){
        ProfileRoomDb db = ProfileRoomDb.getInstance(app);
        mProfileDao = db.profileDataDao();
        getAllData = mProfileDao.getAllData();
    }
    public void insert(ProfileData profileData) {
        new InsertAsyncTask(mProfileDao).execute(profileData);
    }
    public List<ProfileData> getAllData(){
        return getAllData;
    }
    private static class InsertAsyncTask extends AsyncTask<ProfileData,Void,Void>{
        private final ProfileDataDao mProfileDao;
        public InsertAsyncTask(ProfileDataDao profileDataDao){
            mProfileDao = profileDataDao;
        }
        @Override
        protected Void doInBackground(ProfileData... profileData) {
            mProfileDao.insert(profileData[0]);
            return null;
        }
    }
}