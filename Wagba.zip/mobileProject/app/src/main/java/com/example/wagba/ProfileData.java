package com.example.wagba;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "ProfileData")
public class ProfileData {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "fullName")
    private final String fullName;
    @ColumnInfo(name = "address")
    private final String address;
    public ProfileData(int id, String fullName, String address) {
        this.fullName = fullName;
        this.address = address;
        this.id = id;
    }
    @Ignore
    public ProfileData(String fullName, String address) {
        this.fullName = fullName;
        this.address = address;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getFullName() {
        return fullName;
    }
    public String getAddress() {
        return address;
    }
}