package com.example.wagba.cart;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.wagba.R;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

class CartViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    public final TextView name;
    public final TextView price;
    public CartViewHolder(@NonNull View itemView) {
        super(itemView);
        name = (TextView) itemView.findViewById(R.id.cartItem);
        price = (TextView) itemView.findViewById(R.id.cartItemPrice);
    }
    @Override
    public void onClick(View view) {
    }
}
public class CartAdapter extends RecyclerView.Adapter<CartViewHolder> {
    private final List<Order> listData;
    private final Context context;
    public CartAdapter(List<Order> listData, Context context) {
        this.listData = listData;
        this.context = context;
    }
    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.cart_layout,parent,false);
        return new CartViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        Locale locale = new Locale("en","US");
        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(locale);
        int Price = (Integer.parseInt(listData.get(position).getPrice()));
        holder.price.setText(numberFormat.format(Price));
        holder.name.setText(listData.get(position).getProductName());
    }
    @Override
    public int getItemCount() {
        return listData.size();
    }
}