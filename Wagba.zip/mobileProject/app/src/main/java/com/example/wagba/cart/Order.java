package com.example.wagba.cart;

public class Order {
    private String ProductId;
    private String ProductName;
    private String Price;
    public Order() {
    }
    public Order(String productId, String productName, String price) {
        ProductId = productId;
        ProductName = productName;
        Price = price;
    }
    public String getProductId() {
        return ProductId;
    }
    public String getProductName() {
        return ProductName;
    }
    public String getPrice() {
        return Price;
    }
}