package com.example.wagba.restaurants;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.wagba.ItemClickListener;
import com.example.wagba.R;

public class MenuViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public final TextView restaurantName;
    public final ImageView restaurantImage;
    private ItemClickListener itemClickListener;
    public MenuViewHolder(@NonNull View itemView) {
        super(itemView);
        restaurantName = (TextView) itemView.findViewById(R.id.RestaurantNameTV);
        restaurantImage = (ImageView) itemView.findViewById(R.id.RestaurantImage);
        itemView.setOnClickListener(this);
    }
    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }
    @Override
    public void onClick(View view) {
        itemClickListener.onClick(getBindingAdapterPosition());
    }
}