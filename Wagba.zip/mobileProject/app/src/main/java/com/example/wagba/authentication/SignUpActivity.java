package com.example.wagba.authentication;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wagba.ProfileData;
import com.example.wagba.ProfileRoomDb;
import com.example.wagba.R;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class SignUpActivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private EditText email, password, fullName, address;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        firebaseAuth = FirebaseAuth.getInstance();
        email = findViewById(R.id.SignUpEmail);
        password = findViewById(R.id.SignUpPassword);
        fullName = findViewById(R.id.SignUpName);
        address = findViewById(R.id.SignUpAddress);
        Button signUp = findViewById(R.id.SignUpBTN);
        TextView loginRedirect = findViewById(R.id.LoginRedirectTV);
        ProfileRoomDb profileRoomDb = ProfileRoomDb.getInstance(this);
        signUp.setOnClickListener(view -> {
            String user = email.getText().toString().trim();
            String pass = password.getText().toString().trim();
            String name = fullName.getText().toString();
            String addr = address.getText().toString();
            if(user.isEmpty())
                email.setError("Email can not be empty!");
            if(pass.isEmpty())
                password.setError("Password can not be empty!");
            if(name.isEmpty())
                fullName.setError("Please enter your Name!");
            if(addr.isEmpty())
                address.setError("Please enter your Address!");
            else{
                firebaseAuth.createUserWithEmailAndPassword(user, pass).addOnCompleteListener(task -> {
                    if(task.isSuccessful()){
                        Toast.makeText(SignUpActivity.this, "Signed Up Successfully!", Toast.LENGTH_SHORT).show();
                        profileRoomDb.profileDataDao().insert(new ProfileData(name,addr));
                        startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                    } else
                        Toast.makeText(SignUpActivity.this, "Signing Up Failed!" + Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        });
        loginRedirect.setOnClickListener(view -> startActivity(new Intent(SignUpActivity.this, LoginActivity.class)));
    }
}