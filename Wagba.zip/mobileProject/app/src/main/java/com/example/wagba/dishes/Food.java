package com.example.wagba.dishes;

public class Food {
    String Name, Price, Image, MenuID, Availability;
    public Food() {
    }
    public Food(String name, String price, String image, String menuID, String availability) {
        Name = name;
        Price = price;
        Image = image;
        MenuID = menuID;
        Availability = availability;
    }
    public String getName() {
        return Name;
    }
    public void setName(String name) {
        Name = name;
    }
    public String getPrice() {
        return Price;
    }
    public String getImage() {
        return Image;
    }
    public String getAvailability() {
        return Availability;
    }
}