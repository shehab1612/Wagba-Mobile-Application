package com.example.wagba;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ProfileDataDao {
    @Insert
    void insert(ProfileData profileData);
    @Query("SELECT * FROM ProfileData")
    List<ProfileData> getAllData();
}