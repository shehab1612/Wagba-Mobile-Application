package com.example.wagba.cart;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wagba.Database.Database;
import com.example.wagba.ProfileData;
import com.example.wagba.ProfileRoomDb;
import com.example.wagba.R;
import com.example.wagba.tracking.Request;
import com.example.wagba.tracking.Tracking;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Cart extends AppCompatActivity {
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    FirebaseDatabase firebaseDatabase;
    TextView subT, deliveryT, T;
    Button button;
    List<Order> cart = new ArrayList<>();
    CartAdapter cartAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        firebaseDatabase = FirebaseDatabase.getInstance();
        recyclerView = (RecyclerView) findViewById(R.id.listCart);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        subT = (TextView) findViewById(R.id.subTotal);
        deliveryT = (TextView) findViewById(R.id.deliveryTotal);
        T = (TextView) findViewById(R.id.total);
        button = (Button) findViewById(R.id.btnPlaceOrder);
        ProfileRoomDb profileRoomDb = ProfileRoomDb.getInstance(this);
        List<ProfileData> arrProfile = (List<ProfileData>) profileRoomDb.profileDataDao().getAllData();
        String addressFromDB = arrProfile.get(0).getAddress();
        DatabaseReference databaseReference;
        databaseReference = firebaseDatabase.getReference("Requests");
        String status = "Order Requested";
        button.setOnClickListener(view -> {
            if(cartAdapter.getItemCount()==0)
                Toast.makeText(Cart.this,"Please add any items to the Cart before Payment and Tracking!",Toast.LENGTH_LONG).show();
            else {
                Request request = new Request(status, addressFromDB, T.getText().toString(), cart);
                databaseReference.child(String.valueOf(System.currentTimeMillis())).setValue(request);
                new Database(getBaseContext()).cleanCart();
                Toast.makeText(Cart.this, "Order Placed, You can now track your order!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Cart.this, Tracking.class));
                finish();
            }
        });
        loadCart();
    }
    private void loadCart() {
        cart = new Database(this).getCarts();
        cartAdapter = new CartAdapter(cart,this);
        recyclerView.setAdapter(cartAdapter);
        int SubTotal = 0;
        for(Order order:cart)
            SubTotal+=(Integer.parseInt(order.getPrice()));
        Locale locale = new Locale("en","US");
        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(locale);
        subT.setText(numberFormat.format(SubTotal));
        double DeliveryTotal = SubTotal*0.1;
        double Total = SubTotal+DeliveryTotal;
        deliveryT.setText(numberFormat.format(DeliveryTotal));
        T.setText(numberFormat.format(Total));
    }
}