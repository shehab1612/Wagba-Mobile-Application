package com.example.wagba.dishes;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.wagba.ItemClickListener;
import com.example.wagba.R;

public class FoodViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public final TextView dishName;
    public final ImageView dishImage;
    private ItemClickListener itemClickListener;
    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }
    public FoodViewHolder(@NonNull View itemView) {
        super(itemView);
        dishName = (TextView) itemView.findViewById(R.id.DishNameTV);
        dishImage = (ImageView) itemView.findViewById(R.id.DishImage);
        itemView.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        itemClickListener.onClick(getBindingAdapterPosition());
    }
}