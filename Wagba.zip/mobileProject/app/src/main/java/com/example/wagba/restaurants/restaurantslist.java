package com.example.wagba.restaurants;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.wagba.R;
import com.example.wagba.tracking.Tracking;
import com.example.wagba.cart.Cart;
import com.example.wagba.dishes.disheslist;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class restaurantslist extends AppCompatActivity {
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    FirebaseRecyclerAdapter<Restaurant, MenuViewHolder> firebaseRecyclerAdapter;
    Button cart,track;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurantslist);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Restaurants");
        recyclerView = (RecyclerView) findViewById(R.id.RestaurantsRV);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        loadRestaurants();
        cart = (Button) findViewById(R.id.goToCartBTN);
        track = (Button) findViewById(R.id.goToTrackingBTN);
        cart.setOnClickListener(view -> {
            Intent cartIntent = new Intent(restaurantslist.this, Cart.class);
            startActivity(cartIntent);
        });
        track.setOnClickListener(view -> {
            Intent trackIntent = new Intent(restaurantslist.this, Tracking.class);
            startActivity(trackIntent);
        });
    }
    private void loadRestaurants() {
            firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Restaurant, MenuViewHolder>(Restaurant.class,R.layout.restaurantitem,MenuViewHolder.class,databaseReference) {
            @Override
            protected void populateViewHolder(MenuViewHolder viewHolder, Restaurant model, int position) {
                viewHolder.restaurantName.setText(model.getName());
                Picasso.with(getBaseContext()).load(model.getImage()).into(viewHolder.restaurantImage);
                viewHolder.setItemClickListener((position1) -> {
                    Intent dishesList = new Intent(restaurantslist.this, disheslist.class);
                    dishesList.putExtra("RestaurantsID",firebaseRecyclerAdapter.getRef(position1).getKey());
                    startActivity(dishesList);
                });
            }
        };
        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }
}