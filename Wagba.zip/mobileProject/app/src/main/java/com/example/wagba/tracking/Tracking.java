package com.example.wagba.tracking;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.wagba.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Tracking extends AppCompatActivity {
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    FirebaseRecyclerAdapter<Track, TrackViewHolder> firebaseRecyclerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracking);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Requests");
        recyclerView = (RecyclerView) findViewById(R.id.listTracking);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        loadRequests();
    }
    private void loadRequests() {
        firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Track, TrackViewHolder>(Track.class,R.layout.tracking_item,TrackViewHolder.class,databaseReference) {
            @Override
            protected void populateViewHolder(TrackViewHolder viewHolder, Track model, int position) {
                viewHolder.address.setText(model.getAddress());
                viewHolder.total.setText(model.getTotal());
                viewHolder.status.setText(model.getStatus());
            }
        };
        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }
}