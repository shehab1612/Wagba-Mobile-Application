package com.example.wagba.dishes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;


import com.example.wagba.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class disheslist extends AppCompatActivity {
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    String restaurantsID = "";
    FirebaseRecyclerAdapter<Food, FoodViewHolder> firebaseRecyclerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disheslist);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Food");
        recyclerView = (RecyclerView) findViewById(R.id.DishesRV);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        if(getIntent() != null)
            restaurantsID = getIntent().getStringExtra("RestaurantsID");
        if(!restaurantsID.isEmpty())
            loadDishes(restaurantsID);
    }
    private void loadDishes(String restaurantsID) {
        firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Food, FoodViewHolder>(Food.class,R.layout.dishitem,FoodViewHolder.class,databaseReference.orderByChild("MenuID").equalTo(restaurantsID)) {
            @Override
            protected void populateViewHolder(FoodViewHolder viewHolder, Food model, int position) {
                viewHolder.dishName.setText(model.getName());
                Picasso.with(getBaseContext()).load(model.getImage()).into(viewHolder.dishImage);
                viewHolder.setItemClickListener((position1) -> {
                    Intent foodDetail = new Intent(disheslist.this, FoodDetail.class);
                    foodDetail.putExtra("FoodID", firebaseRecyclerAdapter.getRef(position1).getKey());
                    startActivity(foodDetail);
                });
            }
        };
        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }
}