package com.example.wagba.tracking;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.wagba.R;

public class TrackViewHolder extends RecyclerView.ViewHolder {
    public final TextView address;
    public final TextView total;
    public final TextView status;
    public TrackViewHolder(@NonNull View itemView) {
        super(itemView);
        address = (TextView) itemView.findViewById(R.id.addressTracking);
        total = (TextView) itemView.findViewById(R.id.totalTracking);
        status = (TextView) itemView.findViewById(R.id.statusTracking);
    }
}