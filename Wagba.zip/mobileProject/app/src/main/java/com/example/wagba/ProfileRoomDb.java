package com.example.wagba;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = ProfileData.class, exportSchema = false, version = 1)
public abstract class ProfileRoomDb extends RoomDatabase {
    private static ProfileRoomDb instance;
    public abstract ProfileDataDao profileDataDao();
    public static synchronized ProfileRoomDb getInstance(Context context){
        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(), ProfileRoomDb.class, "profile-database").fallbackToDestructiveMigration().allowMainThreadQueries().build();
        }
        return instance;
    }
    private static final RoomDatabase.Callback roomCallBack = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDataAsyncTask(instance).execute();
        }
        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);
        }
    };
    private static class PopulateDataAsyncTask extends AsyncTask<Void,Void,Void>{
        PopulateDataAsyncTask(ProfileRoomDb db){
            ProfileDataDao mProfileDao = db.profileDataDao();
        }
        @Override
        protected Void doInBackground(Void... voids) {
            return null;
        }
    }
}