package com.example.wagba.authentication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wagba.MainActivity;
import com.example.wagba.R;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private EditText email, password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        firebaseAuth = FirebaseAuth.getInstance();
        email = findViewById(R.id.LoginEmail);
        password = findViewById(R.id.LoginPassword);
        Button login = findViewById(R.id.LoginBTN);
        TextView signupRedirect = findViewById(R.id.SignUpRedirect);
        login.setOnClickListener(view -> {
            String mail = email.getText().toString();
            String pass = password.getText().toString();
            if(!mail.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                if(!pass.isEmpty()) {
                    firebaseAuth.signInWithEmailAndPassword(mail, pass)
                            .addOnSuccessListener(authResult -> {
                                Toast.makeText(LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                                finish();
                            }).addOnFailureListener(e -> Toast.makeText(LoginActivity.this, "Login Failed!", Toast.LENGTH_SHORT).show());
                } else
                    password.setError("Password can not be empty!");
            } else if(mail.isEmpty())
                email.setError("Email can not be empty!");
            else
                email.setError("Please enter a valid Email!");
        });
        signupRedirect.setOnClickListener(view -> startActivity(new Intent(LoginActivity.this, SignUpActivity.class)));
    }
}