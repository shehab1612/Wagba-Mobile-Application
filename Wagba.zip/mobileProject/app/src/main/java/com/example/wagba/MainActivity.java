package com.example.wagba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.wagba.restaurants.restaurantslist;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    TextView fullName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.StartBTN);
        fullName = findViewById(R.id.userName);
        ProfileRoomDb profileRoomDb = ProfileRoomDb.getInstance(this);
        List<ProfileData> arrProfile = (List<ProfileData>) profileRoomDb.profileDataDao().getAllData();
        String nameFromDB = arrProfile.get(0).getFullName();
        fullName.setText(nameFromDB);
        button.setOnClickListener(view -> startActivity(new Intent(MainActivity.this, restaurantslist.class)));
    }
}