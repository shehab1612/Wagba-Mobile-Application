package com.example.wagba;

public interface ItemClickListener {
    void onClick(int position);
}