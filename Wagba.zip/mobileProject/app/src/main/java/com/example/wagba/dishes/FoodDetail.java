package com.example.wagba.dishes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.wagba.Database.Database;
import com.example.wagba.R;
import com.example.wagba.cart.Order;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class FoodDetail extends AppCompatActivity {
    TextView food_name, food_price, food_availability;
    ImageView food_image;
    FloatingActionButton floatingActionButton;
    String foodId = "";
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    Food food;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_detail);
        food_availability = (TextView) findViewById(R.id.availability);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Food");
        floatingActionButton = (FloatingActionButton) findViewById(R.id.CartBTN);
        floatingActionButton.setOnClickListener(view -> {
            if (food_availability.getText().equals("Available")) {
                new Database(getBaseContext()).addToCart(new Order(
                        foodId,
                        food.getName(),
                        food.getPrice()
                ));
                Toast.makeText(FoodDetail.this, "Added to Cart.", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(FoodDetail.this,"Sorry, This Dish is not available currently!",Toast.LENGTH_SHORT).show();
            }
        });
        food_name = (TextView) findViewById(R.id.foodName);
        food_price = (TextView) findViewById(R.id.foodPrice);
        food_image = (ImageView) findViewById(R.id.foodImage);
        if(getIntent() != null)
            foodId = getIntent().getStringExtra("FoodID");
        if(!foodId.isEmpty()){
            getFoodDetail(foodId);
        }
    }
    private void getFoodDetail(String foodId) {
        databaseReference.child(foodId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                food = dataSnapshot.getValue(Food.class);
                Picasso.with(getBaseContext()).load(food.getImage()).into(food_image);
                food_price.setText(food.getPrice());
                food_name.setText(food.getName());
                food_availability.setText(food.getAvailability());
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
}