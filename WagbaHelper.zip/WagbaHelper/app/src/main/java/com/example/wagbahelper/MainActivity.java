package com.example.wagbahelper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.View;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    FirebaseRecyclerAdapter<Track,TrackViewHolder> firebaseRecyclerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Requests");
        recyclerView = (RecyclerView) findViewById(R.id.listTracking);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        loadRequests();
    }
    private void loadRequests() {
        firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Track, TrackViewHolder>(Track.class,R.layout.tracking_item,TrackViewHolder.class,databaseReference) {
            @Override
            protected void populateViewHolder(TrackViewHolder viewHolder, Track model, int position) {
                viewHolder.address.setText(model.getAddress());
                viewHolder.total.setText(model.getTotal());
                viewHolder.status.setText(model.getStatus());
                viewHolder.button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String newState = viewHolder.editText.getText().toString();
                        HashMap hashMap = new HashMap();
                        hashMap.put("status",newState);
                        databaseReference.child(getRef(position).getKey()).updateChildren(hashMap);
                        viewHolder.editText.setText("");
                    }
                });
            }
        };
        recyclerView.setAdapter(firebaseRecyclerAdapter);
    }
}